package Models;

public class Productos {
    
    protected int idProducto   = 0;
    protected double precioCompra = 0.0;
    protected double precioVenta = 0.0;
    protected int idProveedor = 0;
    protected int idEmpleado = 0;
    
    public Productos(int idProducto,double precioCompra,double precioVenta,int idProveedor,int idEmpleado){
    this.idProducto   = idProducto;
    this.precioCompra = precioCompra;
    this.precioVenta = precioVenta;
    this.idProveedor = idProveedor;
    this.idEmpleado = idEmpleado;
    }

    public void setIdProducto(int idProducto ){
        this.idProducto = idProducto; 
    }

    public void setPrecioCompra(double precioCompra){
        this.precioCompra = precioCompra; 
    }

    public void setPrecioVenta(double precioVenta){
        this.precioVenta = precioVenta; 
    }

    public void setIdProveedor(int idProveedor){
        this.idProveedor = idProveedor; 
    }

    public void setIdEmpleado(int idEmpleado){
        this.idEmpleado = idEmpleado; 
    }

    public int getIdProducto(){
        return idProducto; 
    }

    public double getPrecioCompra(){
        return precioCompra; 
    }

    public double getPrecioVenta(){
        return precioVenta; 
    }

    public int getIdProveedor(){
        return idProveedor; 
    }

    public int getIdEmpleado(){
        return idEmpleado; 
    }

    public void Imprimir(){
           System.out.println("Ya sirve productos "+idProducto+precioCompra+precioVenta+idProveedor+idEmpleado);
        
    }
            
}
