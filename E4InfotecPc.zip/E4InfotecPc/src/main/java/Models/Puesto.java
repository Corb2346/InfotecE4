
package Models;


public class Puesto {
    
    private int idPuesto;
    protected String NombrePuesto;
    private String descripcionPuesto;
    
    public Puesto(int idPuesto,String NombrePuesto,String descripcionPuesto){
        this.idPuesto = idPuesto;
        this.NombrePuesto = NombrePuesto;
        this.descripcionPuesto = descripcionPuesto;
        
    }

    public int getIdPuesto() {
        return idPuesto;
    }

    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }

    public String getDescripcionPuesto() {
        return descripcionPuesto;
    }

    public void setDescripcionPuesto(String descripcionPuesto) {
        this.descripcionPuesto = descripcionPuesto;
    }
    
     public String getNombrePuesto() {
        return NombrePuesto;
    }

    public void setNombrePuesto(String NombrePuesto) {
        this.NombrePuesto = NombrePuesto;
    }
    
     public void Imprimir(){
        System.out.println("si funciona esta clase de puesto"+ idPuesto +NombrePuesto +
                           descripcionPuesto);
    }
    
}
