
package Models;

public class Cliente extends Persona{
    
    private int idCliente;
    
    public Cliente(String nombre,String apellido,String telefono,String correo,int edad,int idCliente){
        super(nombre,apellido,telefono,correo,edad);
        this.idCliente = idCliente;
    }
    
    public int getIdCliente() {
        return idCliente;
    }
    
    @Override
    public void Imprimir(){
        System.out.println("si funciona esta subclase cliente de persona" + nombre + 
                           apellido+telefono+correo+edad +idCliente);
    }
    
}


