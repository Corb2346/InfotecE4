
package Models;

public class Empleado extends Persona {
    
    private int idEmpleado;
    
    public Empleado(String nombre,String apellido,String telefono,String correo,int edad,int idEmpleado){
        super(nombre,apellido,telefono,correo,edad);
        this.idEmpleado = idEmpleado;
        
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }
    
    @Override
     public void Imprimir(){
        System.out.println("si funciona esta subclase empleado de persona" + nombre + 
                           apellido+telefono+correo+edad );
    }
    
}
