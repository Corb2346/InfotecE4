
package Models;

public class Pedidos {
   
    private int idPedido;
    private int idProducto;
    private int idVenta;
    private int idCliente;
    
    public Pedidos(int idPedido,int idProductos,int idVentas,int idClientes){
        this.idPedido = idPedido;
        this.idProducto = idProducto;
        this.idVenta = idVenta;
        this.idCliente = idCliente;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    public void Imprimir(){
        System.out.println("si funciona esta clase pedido" + idPedido + 
                           idVenta+idProducto+idCliente );
    }
    
}
