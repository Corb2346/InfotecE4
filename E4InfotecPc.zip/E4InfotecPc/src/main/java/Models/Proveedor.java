/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author braya
 */
public class Proveedor {
//atributos de proveedor
    protected int idProveedor = 0;
    protected  String nombreEmpresa = "";
    protected  String telefono = "";
    protected  String correo = "";
    
    //Constructor
    public Proveedor(int idProveedor, String nombreEmpresa,String telefono, String correo){
        this.idProveedor = idProveedor;
        this.nombreEmpresa = nombreEmpresa;
        this.telefono = telefono;
        this.correo = correo;
    }
    
    public int getIdProveedor(){
        return idProveedor;
    }

    public String getNombreEmpresa(){
        return nombreEmpresa;
    }

    public String getTelefono(){
        return telefono;
    }
           
    public String getCorreo(){
        return correo;
    }

    public void setIdProveedor(int idProveedor){
        this.idProveedor=0;
        
    }

    public void setNombreEmpresa(String nombreEmpresa){
        this.nombreEmpresa = "";
        
    }

    public void setTelefono(String telefono){
        this.telefono="";
    }

    public void setCorreo(String correo ){
        this.correo = "";
    }
            
    public void Imprimir(){
        System.out.println("si funciona esta clase proveedor" + idProveedor + 
                            nombreEmpresa + telefono + correo );
    }
}

