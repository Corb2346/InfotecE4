
package Models;

public class Computador extends Productos {

    protected int idCategoria   = 0;
    protected String tipoComputadora = "";
    protected String ram = "";
    protected String almacenamiento = "";
    protected String procesador = "";
    protected String modeloComputadora = "";

    //constructor
public Computador(int idProducto,double precioCompra,double precioVenta,int idProveedor,int idEmpleado,int idCategoria, String tipoComputadora , String ram, String almacenamiento, String procesador,String modeloComputadora  ){
        super(idProducto,precioCompra,precioVenta,idProveedor,idEmpleado);
        this.idCategoria = idCategoria;
        this.tipoComputadora =tipoComputadora;
        this.ram =  ram;
        this.almacenamiento = almacenamiento;
        this.procesador = procesador;
        this.modeloComputadora = modeloComputadora;
    }

    public int getIdCategoria(){
        return idCategoria;
    }

    public String getTipoComputadora(){
        return tipoComputadora;
    }

    public String getRam(){
        return ram;
    }
           
    public String getAlmacenamiento(){
        return almacenamiento;
    }

    public String getProcesador(){
        return procesador;
    }

    public String getModeloComputadora(){
        return modeloComputadora;
    }

//metodos set
     public void setIdCategoria(int idCategoria){
        this.idCategoria = idCategoria;
    }

    public void getTipoComputadora(String tipoComputadora){
        this.tipoComputadora = tipoComputadora;
    }

    public void setRam(String ram){
        this.ram = ram;
    }
           
    public void setAlmacenamiento(String almacenamiento){
        this.almacenamiento = almacenamiento;
    }

    public void setProcesador(String procesador){
        this.procesador = procesador;
    }

    public void setModeloComputadora(String modeloComputadora){
       this.modeloComputadora = modeloComputadora;
    }
@Override
    public void Imprimir(){
        System.out.println("si funciona esta clase computadora" + idCategoria  + 
                           tipoComputadora +ram+almacenamiento +
                           modeloComputadora );
    }

}
