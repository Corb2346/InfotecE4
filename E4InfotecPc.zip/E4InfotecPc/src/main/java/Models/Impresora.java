
package Models;

public class Impresora extends Productos{
    
    protected int idCategoria;
    protected int idtinta;
    protected String modeloImpresora;
    
    public Impresora(int idProducto,double precioCompra,double precioVenta,int idProveedor,int idEmpleado,int idCategoria,int idTinta,String modeloImpresora){
        super(idProducto,precioCompra,precioVenta,idProveedor,idEmpleado);
            this.idCategoria = idCategoria;
            this.idtinta = idtinta;
            this.modeloImpresora = modeloImpresora;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getTinta() {
        return idtinta;
    }

    public void setTinta(int tinta) {
        this.idtinta = tinta;
    }

    public String getModeloImpresora() {
        return modeloImpresora;
    }

    public void setModeloImpresora(String modeloImpresora) {
        this.modeloImpresora = modeloImpresora;
    }
    
      public void Imprimir(){
        System.out.println("si funciona esta clase de impresora"+ idCategoria +idtinta+
                           modeloImpresora);
    }
    
    
}
