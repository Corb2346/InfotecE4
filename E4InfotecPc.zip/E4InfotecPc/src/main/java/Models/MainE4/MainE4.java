
package Models.MainE4;

import java.util.Scanner;
import Models.*;
import java.util.ArrayList;

public class MainE4 {
    
private static int inicioSesion = 0;
    private static int idempleado = 0;

    public static void main(String[] args ){

       Proveedor proveedorUno = new Proveedor(1,"Empresa1","5544223366","correoelectronico1@dominio.com");
       Proveedor proveedorDos = new Proveedor(2,"Empresa2","5577884542","correoElectronico2@dominio2.com");
       Proveedor proveedorTres = new Proveedor(3,"Empresa3","5544223366","correoelectronico3@dominio3.com");
       Proveedor proveedorCuatro = new Proveedor(4,"Empresa4","5577884542","correoElectronico4@dominio4.com");
       
       Proveedor[] proveedorArray = new Proveedor[4];

       proveedorArray[0] = new Proveedor(1,"Empresa1","5544223366","correoelectronico1@dominio.com");
       proveedorArray[1] = new Proveedor(2,"Empresa2","5577884542","correoElectronico2@dominio2.com");
       proveedorArray[2] = new Proveedor(3,"Empresa3","5544223366","correoelectronico3@dominio3.com");
       proveedorArray[3] = new Proveedor(4,"Empresa4","5577884542","correoElectronico4@dominio4.com");

       Computador computadoraUno = new Computador (1,50.0,70.99,1,1,1,"escitorio","8GB","128GB","CoreI5","hp754" );
       Computador computadoraDos = new Computador (2,35.24,55.02,2,2,2,"laptop","8GB","264GB","Corei7","Dell456" );
       Computador computadoraTres = new Computador (3,60.01,72.23,1,3,1,"escriiorio","16GB","1TB","Corei5","Amd" );
       Computador computadoraCuatro = new Computador (4,55.5,75.23,3,4,2,"laptop","32GB","1TB","Corei8","Asus" );
       
       Productos [] producto = new Productos[50]; 
       ArrayList<Productos> productosLista = new ArrayList<Productos>();

       productosLista.add(computadoraUno);
       productosLista.add(computadoraDos);
       productosLista.add(computadoraTres);
       productosLista.add(computadoraCuatro);
       
       Venta ventaUno = new Venta(1,12.50);
       Venta ventaDos = new Venta(2,74.5);
       Venta ventaTres = new Venta(3,41.2);
       Venta ventaCuatro = new Venta(4,42.45);
       
       Pedidos pedidoUno = new Pedidos(1,1,1,1);
       Pedidos pedidoDos = new Pedidos(2,2,2,2);
       Pedidos pedidoTres = new Pedidos(3,4,3,3);
       Pedidos pedidoCuatro = new Pedidos(4,1,4,4);
       
       Empleado empleadoUno = new Empleado("Roberto","empleado Apellido","5544223366","correoelectronico1@dominio.com",20,1);
       Empleado empleadoDos = new Empleado("Laura","empleado Apellido2","55454512145","correoelectronico2@dominio.com",25,2);
       Empleado empleadoTres = new Empleado("Sergio","empleado Apellido3","5578932145","correoelectronico3@dominio.com",32,3);
       Empleado empleadoCuatro = new Empleado("Tania","empleado Apellido4","5122354788","correoelectronico4@dominio.com",45,3);
       
       Empleado [] empleados = new Empleado[10]; 
       ArrayList<Empleado> empleadosLista = new ArrayList<Empleado>();
       
       empleadosLista.add(empleadoUno);
       empleadosLista.add(empleadoDos);
       empleadosLista.add(empleadoTres);
       empleadosLista.add(empleadoCuatro);
       
       Cliente clienteUno = new Cliente("beto","cliente apellido1","74859632145","correoelectronico1cliente@dominio.com",18,1);
       Cliente clienteDos = new Cliente("Saul","cliente","12365478936","correoelectronico2cliente@dominio.com",23,2);
       Cliente clienteTres = new Cliente("Aylin","cliente apellido3","5578932145","correoelectronico3cliente@dominio.com",48,3);
       Cliente clienteCuatro = new Cliente("Jessica","cliente Apellido4","5122354788","correoelectronico4@dominio.com",55,4);
       
       Persona [] personas = new Persona[50]; 
       ArrayList<Persona> personasLista = new ArrayList<Persona>();
       
       personasLista.add(empleadoUno);
       personasLista.add(empleadoDos);
       personasLista.add(empleadoTres);
       personasLista.add(empleadoCuatro);
       
       personasLista.add(clienteUno);
       personasLista.add(clienteDos);
       personasLista.add(clienteTres);
       personasLista.add(clienteCuatro);
       
       Puesto puestoUno = new Puesto(1,"Vendedor","Atiende a los clientes y les vende productos");
       Puesto puestoDos = new Puesto(2,"Almacen","Recibe los productos por los proveedores y los mete al sistema");
       Puesto puestoTres = new Puesto(3,"Administrativo","Encargado de pagar, ver inventario que no se quede vacio y llamar a proveedores");

       //public TipoComputadora(int idCategoria, String tipoComputadora , String ram, String almacenamiento, String procesador,String modeloComputadora,int idTipoComputadora,String nombreTipo)
       
       
       //muestra en terminal los datos de cada entidad
       proveedorUno.Imprimir();
       proveedorDos.Imprimir();
       proveedorTres.Imprimir();
       proveedorCuatro.Imprimir();
       
       computadoraUno.Imprimir();
       computadoraDos.Imprimir();
       computadoraTres.Imprimir();
       computadoraCuatro.Imprimir();
       
       ventaUno.Imprimir();
       ventaDos.Imprimir();
       ventaTres.Imprimir();
       ventaCuatro.Imprimir();
       
       pedidoUno.Imprimir();
       pedidoDos.Imprimir();
       pedidoTres.Imprimir();
       pedidoCuatro.Imprimir();
       
       empleadoUno.Imprimir();
       empleadoDos.Imprimir();
       empleadoTres.Imprimir();
       empleadoCuatro.Imprimir();
       
       clienteUno.Imprimir();
       clienteDos.Imprimir();
       clienteTres.Imprimir();
       clienteCuatro.Imprimir();
       
       puestoUno.Imprimir();
       puestoDos.Imprimir();
       puestoTres.Imprimir();
      
       System.out.println("Ya se conectò a la base de datos");
       System.out.println(personasLista);
       System.out.println(empleadosLista);
      
       
       System.out.println("--------------------------------------------");
       
       menuinicio(personasLista,empleadosLista);
       
       System.out.println("obtenido de funcion" + idempleado);
       System.out.println("obtenido de funcion" + inicioSesion);
       
       if(inicioSesion == 0 && idempleado == 0){
           System.out.println("Muestra menu para cliente");
           menuCliente();
       } else if(idempleado==1){
           System.out.println("Muestra menu para empleado vendedor");
       } else if(idempleado==2){
           System.out.println("Muestra menu para empleado almacen");
       } else if(idempleado==3){
           System.out.println("Muestra menu para empleado administrativo");
       } else if(inicioSesion == 2 && idempleado == 0){
           System.out.println("Registrarse como nuevo usuario");
       }
        
       /*menuVendedor();*/
       
     }
    
    private static int menuinicio(ArrayList<Persona> personasLista,ArrayList<Empleado> empleadosLista){
       System.out.println("Iniciar Sesion ");
     
       System.out.println(" Introduce nombre de usuario: ");
       Scanner scanner = new Scanner(System.in);
       String nombreUsuario = scanner.nextLine(); 
       
       System.out.println("Introduce contraseña:  ");  
       String contraseña = scanner.nextLine(); 
        
       System.out.println("--------------------------------------------");
        
        System.out.println("Nombre:" + nombreUsuario);
        System.out.println("Contraseña:" + contraseña);
               
        for(int i =0;i<personasLista.size();i++){
           
            
            String name = personasLista.get(i).getNombre();
            System.out.println(personasLista.get(i).getNombre());

            if(name.contentEquals(nombreUsuario)){
     
                System.out.println("Inicio de sesion exitoso");
                System.out.println("Eres " + name + personasLista.get(i).getClass());
                Class<? extends Persona> classPertence = personasLista.get(i).getClass();
                System.out.println("Eres " + name + classPertence);
                String texto = classPertence.toString();
                System.out.println(i);
                int getIndice = i;
                
                System.out.println("cambiadoa texto" +texto);
                
                if(texto.contains("Cliente")){
                    System.out.println("eres cliente");
                     return inicioSesion = 0;
                } else {
                    System.out.println("eres Empleado");
                     
                        
                     for(i =0;i<empleadosLista.size();i++){
                        
                         String nombreEmpleados = empleadosLista.get(i).getNombre();
                         
                         if(nombreEmpleados == name){
                            System.out.println(empleadosLista.get(i).getIdEmpleado());
                            idempleado = empleadosLista.get(i).getIdEmpleado();
                            System.out.println(idempleado);
                         return idempleado;
                         }

                     }
                        
                }
                
               
            } else { 
                System.out.println("Nombre de usuaio No encontrado");
                System.out.println("No se pudo iniciar Sesion");
               
            }  
        }
        return inicioSesion =2;
    }
    
    
    
    private static void menuCliente(){
        System.out.println("Ya entré al menu de cliente");
    }
    
    private static void menuVendedor() {   
        
        System.out.println("Presiona el inciso al que deseas accesar: ");
        Scanner scanner = new Scanner(System.in);
        int opcionMenu = scanner.nextInt(); 

        switch (opcionMenu){

            case 1:{

                System.out.println("Usted eligió la opcion 1.");

                break;

            }

            case 2:{

                System.out.println("Usted eligió la opcion 2.");

                break;

            }

            case 3:{

                System.out.println("Usted eligió la opcion 3.");

                break;

            }

            default: {

                System.out.println("Opcion incorrecta");

            }

      }//cierra SWITCH*/
    }
       
    
    
}
 
