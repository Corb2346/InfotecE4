package MainE4;
import java.util.Scanner;

public class menuVendedor {
    
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
