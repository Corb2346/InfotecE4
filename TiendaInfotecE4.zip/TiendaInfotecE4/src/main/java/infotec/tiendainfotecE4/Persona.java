
package infotec.tiendainfotecE4;

public class Persona {
    
    protected String nombre;
    protected String apellido;
    protected String telefono; 
    protected String correo;
    protected int edad; 
    
    public Persona(String nombre,String apellido,String telefono,String correo,int edad){
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono; 
        this.correo = correo;
        this.edad = edad; 
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getapellido() {
        return apellido;
    }

    public void setapellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
     public void Imprimir(){
        System.out.println("si funciona esta clase persona" + nombre + 
                           apellido+telefono+correo+edad );
    }
}
