
package infotec.tiendainfotecE4;

public class Sistema extends Computador {
    
    protected int idSistema; 
    protected String nombreSistema;
    
    public Sistema(int idProducto,double precioCompra,double precioVenta,int idProveedor,int idEmpleado,int idCategoria, String tipoComputadora , String ram, String almacenamiento, String procesador,String modeloComputadora,int idSistema,String nombreSistema){
        super(idProducto,precioCompra,precioVenta,idProveedor,idEmpleado,idCategoria,tipoComputadora ,ram, almacenamiento,procesador,modeloComputadora);
        
        this.idSistema = idSistema; 
        this.nombreSistema = nombreSistema;
    }

    public int getIdSistema() {
        return idSistema;
    }

    public void setIdSistema(int idSistema) {
        this.idSistema = idSistema;
    }

    public String getNombreSistema() {
        return nombreSistema;
    }

    public void setNombreSistema(String nombreSistema) {
        this.nombreSistema = nombreSistema;
    }
    
    @Override
      public void Imprimir(){
        System.out.println("si funciona esta subclase sistema de computador"+idSistema+nombreSistema);
    }
    
}


