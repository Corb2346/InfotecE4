
package infotec.tiendainfotecE4;


public class TipoComputadora extends Computador{
    
    private int idTipoComputadora;
    private String nombreTipo;
    
    public TipoComputadora(int idProducto,double precioCompra,double precioVenta,int idProveedor,int idEmpleado,int idCategoria, String tipoComputadora , String ram, String almacenamiento, String procesador,String modeloComputadora,int idTipoComputadora,String nombreTipo){
        super(idProducto,precioCompra,precioVenta,idProveedor,idEmpleado,idCategoria, tipoComputadora ,ram, almacenamiento,procesador,modeloComputadora);
        this.idTipoComputadora = idTipoComputadora;
        this.nombreTipo = nombreTipo;
    }

    public int getIdTipoComputadora() {
        return idTipoComputadora;
    }

    public void setIdTipoComputadora(int idTipoComputadora) {
        this.idTipoComputadora = idTipoComputadora;
    }

    public String getNombreTipo() {
        return nombreTipo;
    }

    public void setNombreTipo(String nombreTipo) {
        this.nombreTipo = nombreTipo;
    }
    
    @Override
      public void Imprimir(){
        System.out.println("si funciona esta subclase tipo de computadora de computador"+idTipoComputadora+nombreTipo);
    }
    
}
