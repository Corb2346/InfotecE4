

package infotec.tiendainfotecE4;


public class VentaB {

//atributos
private int idVenta = 0;
//private Date firstDate = new Date();
private double totalVenta = 0.0;

//constructor
    
public VentaB(int idVenta, double totalVenta){
    this.idVenta = idVenta;
    this.totalVenta = totalVenta;
}

public int getIdVenta(){
    return idVenta;
}

public double getTotaVenta(){
    return totalVenta;
}

public void setIdVenta(int idVenta){
    this.idVenta=idVenta;
}

public void setTotalVenta(double totalVenta){
    this.totalVenta = totalVenta; 
}

  public void Imprimir(){
        System.out.println("si funciona esta clase venta" + idVenta + 
                           totalVenta );
    }
}
